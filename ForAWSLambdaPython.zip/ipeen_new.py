#coding=utf-8
from __future__ import print_function
import requests as r
from bs4 import BeautifulSoup as bs
from queue import Queue
import boto3
import urllib
import json 

#from pymongo import *
import re
import time
from datetime import datetime
from pytz import timezone
import threading
import sys

tStart = time.time()
print('Loading function')
# aws client
s3 = boto3.client('s3')    
bucket = s3.Bucket('ab105diamondsbucket')
def lambda_handler(event, context):
	url_base = 'http://www.ipeen.com.tw'

	# setting time zone
    taipei_time = timezone('Asia/Taipei')

    now = datetime.now(taipei_time)
    print(now)
    fmt = '%Y-%m-%d'
    print (now.strftime(fmt))
    nowdate = now.strftime(fmt)
   
# if __name__ == '__main__': 
    
    
    
    
    # lock = threading.Lock()  #命名一個 Lock 物件
    # q = Queue() # 開一個 Queue 物件
    # t1 = threading.Thread(target=comment_crawler, args=(comment_page)) 
                                # 打開一個名字叫 t1 的線程物件
                                # 這個物件會去呼叫 job1
                                # 同時t1導入 q 跟 lock 做現成控制

    # start = time.time()
    # t1.start()  #啟動 t1 線程

    # t1.join()  #在 t1線程結束前阻止程式繼續運行


      

    # 確認Queue是否為空，如果不是就用 q.get() 取出值
    # while not q.empty():   
        # comment_crawler(q.get())
    # end = time.time()
    # elapsed = end - start
    # print("Time taken: ", elapsed, "seconds.")    

	
	
	

#爬取食記裡所需要的資料
	def comment_crawler(comment_page):		

	
		total_list=[]
		
		#注意用法，因為寫入的txt檔有問題
		# for url in range(len(comment_page_list)):
			# url = comment_page_list.pop().strip()
			# print(url)
		
		#for url in comment_page:
		for pre_url in range(len(comment_page_list)):
		
			try: 
		#         url = 'http://www.ipeen.com.tw/comment/{}'.format(i)
				#新增的一行
				url = comment_page_list.pop().strip()
				res = r.get(url)
				res.encoding="utf-8"
				soup = bs(res.text, 'lxml')
				mydict = {}
				#餐廳名稱
				restaurant_name = soup.select('.brief > p > a')[0].text.strip()
				mydict['restaurant_name'] = restaurant_name

				#餐廳地址
				restaurant_location = soup.select('.info > ul > li')[2].text.split('：')[1].split('(')[0].strip()
				mydict['restaurant_location'] = restaurant_location

				#電話號碼
				phone_number = soup.select('.info > ul > li')[1].text.split('：')[1]
				mydict['phone_number'] = phone_number

				#發表日期
				created_date = soup.select('.date > span')[0].text
				mydict['created_date'] = created_date

				#營業時間
				open_time_list=[]

				open_time = soup.select('.businessHour-right > span')
		#         for one_time in open_time:
		#             open_time_list.append(one_time.text)
		#         if open_time_list 
		#         mydict['open_time'] = open_time_list
				for one_time in open_time:
					if '、' in one_time.text:
						one_time_text = one_time.text.split("、")[0]
						open_time_list.append(one_time_text)
					else:
						open_time_list.append(one_time.text)
				if len(open_time_list)>1: 
					open_time_str = "\t".join(open_time_list)
		#             print(open_time_str)  
					mydict['open_time'] = open_time_str
				else:
					mydict['open_time'] = open_time_list[0]

				#平均消費
				avg_consume = soup.select('.other > ul > li')[3].text.split('：')[1].strip().split(' ')[0]
				if ',' in avg_consume:
					c1 = avg_consume.split(',')
					c2 = ''.join(c1)
					mydict['avg_consume'] = int(c2)
					
				else:
					mydict['avg_consume'] = int(avg_consume)
				

				#url
				mydict['web_url'] = url

				#美味度
				# deli = soup.select('.rating > dt')
				# for d in deli:
				#     n = deli.index(d)

				delicious = soup.select('.rating > dd')[0].text
				mydict['delicious'] = delicious

				#服務品質
				service_quality = soup.select('.rating > dd')[1].text
				mydict['service_quality'] = service_quality

				#環境氣氛
				dining_environment = soup.select('.rating > dd')[2].text
				mydict['dining_environment'] = dining_environment

				#作者名稱
				author_name = soup.find_all('a',{'data-action':'header_user'})[1].select('span')[0].text
				mydict['author_name'] = author_name

				#作者url
				a_url = soup.find_all('a',{'data-action':'header_user'})[0].get('href').split('../')[1]
				author_url = url + '/' + a_url
				mydict['author_url'] = author_url
			   
				#種類
				category = soup.find_all('span',{'itemprop':'title'})[4].text
				mydict['category'] = category
				
				#餐廳評論
				comment = soup.select('.description')[0].text.strip()
				mydict['comment'] = comment
			   
				
				#圖片url
				image_list = []
				images = soup.select('.description')[0].find_all('img')
				for image in images:
					image_url = image.get('src')
					image_list.append(image_url)
				image_url_count = len(image_list)    
				mydict['image_url_count'] =  image_url_count   
				
				#評分
				rate = soup.find('meter',{'max':'50'}).select('span')[0].text
				mydict['rate'] = int(rate)
				
				#瀏覽人數
				read = soup.select('div.actions > span')[1].text.split(' ')[1]
				if ',' in read:
					r1 = read.split(',')
					r2 = ''.join(r1)
					mydict['view'] = int(r2)
					
				else:
					mydict['view'] = int(read)
					
				#分享
				share = soup.find('a',{'data-action':'right_shopcomment'}).text.split('人')[0]
				mydict['share'] = int(share)
				
				
				#id
				_id = "ipeen_"+author_name+'_'+created_date
				mydict['_id'] = _id
		#         time.strftime("%Y/%m/%d_%H:%M:%S")  現在時間日期
				
				#寫進mongoDB
		#         goto_mongo(mydict)
				#print(mydict)
				total_list.append(mydict)
				
			except IndexError: 
				print("[ERROR] : empty comment!")
				
			finally:
				tEnd = time.time()
				if (tEnd - tStart >= 280):
					break
				
		pre_data = json.dumps(total_list, ensure_ascii=False)
		#轉換成byte
		data = pre_data.encode('utf8')
		
		#寫進json檔
		# with open('ipeen.json', 'w',encoding='utf8') as f:
			# data = json.dumps(total_list, ensure_ascii=False)		
			# f.write(data)
				#把每個dictionary都回傳給上個function並裝成list
				# return mydict
        #寫進s3檔
        s3.put_object(Body=data.read(), Bucket='ab105diamondsbucket', Key='ipeen'+ '/' + nowdate + '/' + tStart + '.json')
		
		#剩下沒爬完的寫回原檔案
		comments_str = ''
		for comment in comment_page_list:
			comments_str += comment
		s3.put_object(Body=comments_str.read(),Bucket='ab105diamondsbucket',Key='ipeen_comment_url/text_1')
	
	response = client.get_object(Bucket='ab105diamondsbucket', Key='ipeen_comment_url/text_1')
	pre_comment_page_list = response['Body']
	comment_page_list = pre_comment_page_list.readlines()
		
	comment_crawler(comment_page_list)
	
	return response['ContentType']
        
##寫進mongoDB裡面
# def goto_mongo(total_list):
    # client = MongoClient()
    # db = client['test']
    # collect = db['test_ipeen']
    # 一次insert一整個list
    # collect.insert_many(total_list)        
               